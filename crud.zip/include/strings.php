<?php 

    $name="";
    $phone="";
    $address="";
    $packageId="";
    $checkIn="";
    $checkOut="";
    $payMode="";
    $adults=1;
    $children=0;
    $packagePrice="";
    $subTotal=""; 
    $discount=""; 
    $total=""; 
    $paid=""; 
    $rem=""; 


$couponCode="";
$couponType="";
$couponValue="";
$minValue="";
$expiredOn="";

  $packageName="";
  $packagePrice="";
  $packageDesc="";
  $packageDuration="";
  $packageLocation="";
  $packageDis="";
  $packageDisType="";
  $image_status='required';

  $name="";
  $phone="";
  $query="";
  $date="";


?>